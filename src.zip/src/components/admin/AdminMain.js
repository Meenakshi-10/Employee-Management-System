import React, { Component } from 'react';
import { Button } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css'; 
import Employee from './addemp';
import SearchEmp from './SearchEmp';
import Empdel from './Empdel';
import GetSkills from './getSkills';
import pic from "../images/main.jpg"

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";

const divStyle = {
	//float: 'left',
	width:'500px',
	height:'600px',
	border:'solid 1px white',
	color:'black',
	margin:'100px 50px',
	align: 'left',
	textAlign: 'center'
};

const Style = {
	float: 'right',
	width:'300px',
	height:'400px',
	margin:'-90px 200px'
};

const btnStyle = {
	display: 'inline-block',
	margin: '0px 40px',
	backgroundColor: 'white',
	border: '2px solid black'
};

class AdminMain extends Component{

    render(){
        return(
            <div>
			<img src={pic} alt="img" align="left" style={Style} />
			   <Router>
			   <div style={divStyle}>
			    <Link to='/dashboard/Employee'>
					<Button style={btnStyle}>Insert Employee</Button>
				</Link>
                <br/>
                <br/>
				<Link to='/dashboard/Empdel'>
					<Button style={btnStyle}>Delete Employee</Button>
				</Link>
                <br/>
                <br/>
				<Link to='/dashboard/SearchEmp'>
					<Button style={btnStyle}>View Employee Details</Button>
				</Link>
				<br/>
                <br/>
				<Link to='/dashboard/GetSkills'>
					<Button style={btnStyle}>View Employee Skillset</Button>
				</Link>
				
				<Route path='/dashboard/Employee' component={Employee}/>
				<Route path='/dashboard/SearchEmp' component={SearchEmp}/>
				<Route path='/dashboard/Empdel' component={Empdel}/>
				<Route path='/dashboard/GetSkills' component={GetSkills}/>
				</div>
				<br/> <br/> <br/>
			   </Router>
            </div>
        );
    }
}

export default AdminMain;