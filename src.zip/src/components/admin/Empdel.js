import React, { Component } from 'react';
import 'semantic-ui-css/semantic.min.css'
import axios from 'axios' ;
import {Form,Button} from 'semantic-ui-react';


const divStyle = {
			position: 'absolute',
			margin: '20px 150px',
			width: '50%',
			align: 'center'
		};
		
class Empdel extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            ssn: 0
         }
    }

    myChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        axios.delete("http://localhost:5000/delEmp", {params: {ssn: this.state.ssn}})
    }
	
	

render(){
    return(
	<div style={divStyle}>
    <Form onSubmit = {this.handleSubmit} align= "center" style={divStyle}>
        <br/> <br/> <br/> <br/> <br/> <br/>
        <h1>Delete Employee</h1>
        <Form.Field>
            <label>Employee SSN</label>
            <input placeholder='Employee SSN' name="ssn" type="number" onChange= {this.myChangeHandler}/>
        </Form.Field>

        <Button type='submit'>Submit</Button>
  </Form>
  </div>
);
}

}

export default Empdel;