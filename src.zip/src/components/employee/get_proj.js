import React, { Component } from 'react';
import 'semantic-ui-css/semantic.min.css'
import axios from 'axios' ;
import {Form,Button} from 'semantic-ui-react';
import ReactTable from "react-table-6"; 
import 'react-table-6/react-table.css'


const divStyle = {
			position: 'absolute',
			margin: '10px 200px',
			width: '80%',
			align: 'center'
		};
const divStyle2 = {
			//position: 'absolute',
			width: '50%',
			align: 'center'
		};
const divStyle3 = {
			//position: 'absolute',
			width: '50%',
			align: 'left'
		};
class Project extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            ssn: 0,
            searchResult: []
         }
    }

    myChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        axios.get("http://localhost:5000/allProj", {
            params: {
                ssn:this.state.ssn
            }
        })
        .then(res => {
            const emp=res.data;
            this.setState({searchResult:emp});
        })
    }

render(){

    const columns = [
        {
            Header: 'Project ID',  
            accessor: 'pid',
        },
        {
        Header: 'Name',  
        accessor: 'name',
        },
        {  
        Header: 'Budget',  
        accessor: 'budget',
        }
    ]

    return(
    <div style={divStyle}>
        <Form onSubmit = {this.handleSubmit} align="center" style={divStyle2}>
            <br/><br/> <br/> <br/> <br/> <br/>
            <h1>Show Projects Currently Working On</h1>
            <Form.Field>
                <label>Employee SSN</label>
                <input placeholder='Employee SSN' name="ssn" type="number" onChange= {this.myChangeHandler}/>
            </Form.Field>

            <Button type='submit'>Submit</Button>
        </Form>
        <br/><br/>
		<div style= {divStyle3}>
        <ReactTable  
            data={this.state.searchResult}  
            columns={columns}  
         />
        </div>
  </div>
);
}

}

export default Project;