DROP DATABASE employeemanagement;
CREATE DATABASE employeemanagement;
\c employeemanagement;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users(
  user_id UUID DEFAULT uuid_generate_v4(),
  user_name VARCHAR(255) NOT NULL,
  user_email VARCHAR(255) NOT NULL UNIQUE,
  user_password VARCHAR(255) NOT NULL,
  PRIMARY KEY (user_id)
);

CREATE TABLE todos(
  todo_id SERIAL,
  user_id UUID,
  description VARCHAR(255) NOT NULL,
  PRIMARY KEY (todo_id),
  FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE Building (
  bid Int,
  name varchar(100),
  capacity Int,
  PRIMARY KEY (bid)
);

CREATE TABLE Salary_Range (
  grade Int,
  start_sal Int,
  end_sal Int,
  PRIMARY KEY (grade)
);

CREATE TABLE Employee (
  ssn Int,
  b_date Date,
  Status varchar(100),
  sex varchar(10),
  s_name varchar(100),
  l_name varchar(100),
  address varchar(500),
  grade Int,
  PRIMARY KEY (ssn),
  CONSTRAINT FK_Employee_grade
    FOREIGN KEY (grade)
      REFERENCES Salary_Range(grade)
);

CREATE TABLE Department (
  did Int,
  name varchar(100),
  mssn Int,
  PRIMARY KEY (did),
  CONSTRAINT FK_Department_mssn
    FOREIGN KEY (mssn)
      REFERENCES Employee(ssn)
);

CREATE TABLE Department_Building (
  did Int,
  bid Int,
  PRIMARY KEY (bid,did),
  CONSTRAINT FK_houses_did
    FOREIGN KEY(did)
      REFERENCES Department(did),

  CONSTRAINT FK_houses_bid
    FOREIGN KEY (bid)
      REFERENCES Building(bid)
);

CREATE TABLE Project (
  pid Int,
  name varchar(100),
  budget Int,
  PRIMARY KEY (pid)
);

CREATE TABLE Project_Department (
  pid Int,
  did Int,
  PRIMARY KEY(pid,did),
  CONSTRAINT FK_assigned_to_pid
    FOREIGN KEY (pid)
      REFERENCES Project(pid),
  
  CONSTRAINT FK_assigned_to_did
    FOREIGN KEY (did)
      REFERENCES Department(did)
);

CREATE TABLE Employee_Department (
  ssn Int,
  did Int,
  PRIMARY KEY (ssn,did),
  CONSTRAINT FK_works_in_ssn
    FOREIGN KEY (ssn)
      REFERENCES Employee(ssn),
  CONSTRAINT FK_works_in_did
    FOREIGN KEY (did)
      REFERENCES Department(did)
);

CREATE TABLE Dependents (
  name varchar(100),
  ssn Int,
  sex varchar(10),
  b_date Date,
  relationship varchar(100),
  PRIMARY KEY (ssn,name),
  CONSTRAINT FK_Dependents_ssn
    FOREIGN KEY (ssn)
      REFERENCES Employee(ssn)
);




CREATE TABLE Leave_type (
  lid Int,
  type varchar(50),
  noOfDays Int,
  PRIMARY KEY (lid)
);

CREATE TABLE Employee_Leave(
  ssn Int,
  lid Int,
  l_date Date,
  no_of_days Int,
  PRIMARY KEY (ssn,lid),
  CONSTRAINT FK_Avails_leave_ssn
    FOREIGN KEY (ssn)
      REFERENCES Employee(ssn),
  CONSTRAINT FK_Avails_leave_lid
    FOREIGN KEY (lid)
      REFERENCES Leave_type(lid)
);

CREATE TABLE Skill (
  sid Int,
  name varchar(100),
  tech varchar(100),
  PRIMARY KEY (sid)
);

CREATE TABLE Employee_Skill (
  ssn Int,
  sid Int,
  PRIMARY KEY(ssn,sid),
  CONSTRAINT FK_Skill_ssn
    FOREIGN KEY (ssn)
      REFERENCES Employee(ssn),
  CONSTRAINT FK_Skill_sid
    FOREIGN KEY (sid)
      REFERENCES Skill(sid)
);

CREATE TABLE Employee_Project (
  start_date Date,
  hours Int,
  ssn Int,
  pid Int,
  PRIMARY KEY (ssn,pid),
  CONSTRAINT FK_Works_On_ssn
    FOREIGN KEY (ssn)
      REFERENCES Employee(ssn),
  CONSTRAINT FK_Works_On_pid
    FOREIGN KEY (pid)
      REFERENCES Project(pid)
);