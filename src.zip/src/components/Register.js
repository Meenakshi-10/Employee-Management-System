import React, { Fragment, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import loginPic from "./images/register.jpg"

const divStyle = {
	position: 'fixed',
	width:'500px',
	height:'600px',
	border:'solid 1px white',
	margin:'0px -100px',
	align: 'left'
};
const divStyle2 = {
	float: 'left',
	position: 'relative',
	margin: '200px 100px'
};
const Style = {
	
	width:'400px',
	height:'500px',
	margin:'100px 800px'
};
const btnStyle = {
	display: 'inline-block',
	margin: '0px 200px',
	border: '2px solid black'
};

const Register = ({ setAuth }) => {
  const [inputs, setInputs] = useState({
    email: "",
    password: "",
    name: ""
  });

  const { email, password, name } = inputs;

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value });

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const body = { email, password, name };
      const response = await fetch(
        "http://localhost:5000/authentication/register",
        {
          method: "POST",
          headers: {
            "Content-type": "application/json"
          },
          body: JSON.stringify(body)
        }
      );
      const parseRes = await response.json();

      if (parseRes.jwtToken) {
        localStorage.setItem("token", parseRes.jwtToken);
        setAuth(true);
        toast.success("Registered Successfully");
      } else {
        setAuth(false);
        toast.error('parseRes error: ', parseRes);
      }
    } catch (err) {
      console.error('onSubmit form error: ', err.message);
    }
  };

  return (
    <Fragment style>
	<div style={divStyle}>
	<img src={loginPic} alt="img" align="left" style={Style} />
	</div>
      
      <form onSubmit={onSubmitForm} style={divStyle2}>
	  <h1 className="mt-5 text-center" style={{color:"grey"}}>Register</h1>
        <input
          type="text"
          name="email"
          value={email}
          placeholder="Email"
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="password"
          name="password"
          value={password}
          placeholder="Password"
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="text"
          name="name"
          value={name}
          placeholder="Type (admin/employee)"
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <button className="btn btn-default" style={btnStyle}>Submit</button>
      </form>
    </Fragment>
  );
};

export default Register;
