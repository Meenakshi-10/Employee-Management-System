import React, { Fragment, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import loginPic from "./images/login.jpg"

const divStyle = {
	position: 'fixed',
	width:'500px',
	height:'600px',
	border:'solid 1px white',
	color:'grey',
	margin:'150px 50px',
	align: 'left',
	textAlign: 'center'
};
const Style = {
	
	width:'600px',
	height:'400px',
	margin:'100px 600px'
};
const btnStyle = {
	display: 'inline-block',
	margin: '0px 200px',
	border: '2px solid black'
};

const Login = ({ setAuth }) => {
  const [inputs, setInputs] = useState({
    email: "",
    password: ""
  });

  const { email, password } = inputs;

  const onChange = e =>
    setInputs({ ...inputs, [e.target.name]: e.target.value });

  const onSubmitForm = async e => {
    e.preventDefault();
    try {
      const body = { email, password };
      const response = await fetch(
        "http://localhost:5000/authentication/login",
        {
          method: "POST",
          headers: {
            "Content-type": "application/json"
          },
          body: JSON.stringify(body)
        }
      );

      const parseRes = await response.json();

      if (parseRes.jwtToken) {
        localStorage.setItem("token", parseRes.jwtToken);
        setAuth(true);
        toast.success("Logged in Successfully");
      } else {
        setAuth(false);
        toast.error(parseRes);
      }
    } catch (err) {
      console.error(err.message);
    }
  };

  return (
    <Fragment>
	  <img src={loginPic} alt="img" align="left" style={Style} />
      <form onSubmit={onSubmitForm} style={divStyle}>
	  <h1 className="mt-5 text-center">Login</h1>
	  <br/>
	  
        <input
          type="text"
          name="email"
          value={email}
		  placeholder="Email"
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
        <input
          type="password"
          name="password"
          value={password}
		  placeholder="Password"
          onChange={e => onChange(e)}
          className="form-control my-3"
        />
		<br/>
        <button className="btn btn-default" style={btnStyle}>Submit</button>
      </form>
      {/* <Link to="/register">register</Link> */}
    </Fragment>
  );
};

export default Login;
