import React, { Component } from 'react';
import 'semantic-ui-css/semantic.min.css'
import axios from 'axios' ;
import {Form,Button} from 'semantic-ui-react';

const divStyle = {
	position: 'absolute',
	width: '50%',
	margin: '100px 150px'
};

class Update_emp extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            ssn: 0,
            address:""
         }
    }

    myChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        const { ssn,b_date,Status,sex,s_name,l_name,address,grade } = this.state;
        axios.post('http://localhost:5000/updateemployee', {
        ssn: ssn,
        address:address
        })
        .then((response) => {
        console.log(response);
        this.props.history.push('/');
        })
        .catch((error) => {
        console.log(error);
        });
    }

    render(){
    return(
    <Form style={divStyle} onSubmit = {this.handleSubmit} align="center">
        <br/>
        <h1>Update Address</h1>
        <Form.Field>
            <label>Employee SSN</label>
            <input placeholder='Employee SSN' name="ssn" type="number" onChange= {this.myChangeHandler}/>
        </Form.Field>

        <Form.Field>
            <label>New Address</label>
            <input placeholder='Address' name="address" type="text" onChange= {this.myChangeHandler}/>
        </Form.Field>

        <Button type='submit'>Submit</Button>
  </Form>
    );

}



}

export default Update_emp;