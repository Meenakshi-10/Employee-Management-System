import React, { Component } from 'react';
import { Button } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css'; 
import { withRouter } from 'react-router-dom'
import Update_emp from './updateEmp';
import Add_Leave from './Add_Leave';
import Project from './get_proj';
import pic from "../images/emp.jpg"

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";
  
  const divStyle = {
	//float: 'left',
	width:'500px',
	height:'600px',
	border:'solid 1px white',
	color:'black',
	margin:'50px 50px',
	align: 'left',
	textAlign: 'center'
};

const Style = {
	float: 'right',
	width:'500px',
	height:'300px',
	margin:'0px 0px'
};

const btnStyle = {
	display: 'inline-block',
	margin: '0px 40px',
	backgroundColor: 'white',
	border: '2px solid black'
};

class EmpMain extends Component{

    render(){
        return(
            <div>
			<img src={pic} alt="img" align="left" style={Style} />
                <Router>
				<div style={divStyle}>
				<br/> <br/> <br/> <br/>
                    <Link to='/dashboard/Update_emp/'>
                        <Button style={btnStyle}>Update Address</Button>
                    </Link>

                    <br/>
                    <br/>

                    <Link to='/dashboard/Add_Leave/'>
                        <Button style={btnStyle}>Update leave</Button>
                    </Link>

                    <br/>
                    <br/>

                    <Link to='/dashboard/Project/'>
                        <Button style={btnStyle}>View Ongoing Projects</Button>
                    </Link>

                    <Route path="/dashboard/Update_emp" component={Update_emp} />
                    <Route path="/dashboard/Add_Leave" component={Add_Leave} />
                    <Route path="/dashboard/Project" component={Project} />
					</div>
                </Router>
            </div>
        );
    }
}

export default EmpMain;