const express = require("express");
const app = express();
const cors = require("cors");
const pool= require("./db");

//middleware

app.use(cors());
app.use(express.json());

//routes

app.use("/authentication", require("./routes/jwtAuth"));

app.use("/dashboard", require("./routes/dashboard"));

app.get("/allproj", async (req, res) => {
  try {
    const e = req.query.ssn;
    const emp = await pool.query("SELECT * FROM project WHERE pid in (SELECT pid FROM employee_project WHERE ssn= $1)" , [e]);
    res.json(emp.rows);
  } catch (err) {
    console.error(err.message);
  }
  });

app.post("/addemployee", async (req, res) => {
    try {
      var e = JSON.parse(JSON.stringify(req.body));
      console.log(e);
      const newEmployee = await pool.query(
        "INSERT INTO employee (ssn,b_date,Status,sex,s_name,l_name,address,grade) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *",
        [e.ssn,e.b_date,e.Status,e.sex,e.s_name,e.l_name,e.address,e.grade]
      );
  
      res.json(newEmployee.rows[0]);
    } catch (err) {
      console.error(err.message);
    }
  });
  
 app.post("/updateemployee", async (req, res) => {
    try {
      console.log(req.body);
      var e = JSON.parse(JSON.stringify(req.body));
      const newEmployee = await pool.query(
        "UPDATE employee SET address = $2 WHERE ssn = $1 RETURNING *",
        [e.ssn,e.address]
      );
  
      res.json(newEmployee.rows[0]);
    } catch (err) {
      console.error(err.message);
    }
  });
  
  
 app.post("/addleave", async (req, res) => {
    try {
      console.log(req.body);
      var l = JSON.parse(JSON.stringify(req.body));
      console.log(l);
      const newLeave = await pool.query(
        "INSERT INTO Employee_Leave (ssn,lid,l_date,no_of_days) VALUES ($1,$2,$3,$4) RETURNING *",
        [l.ssn,l.lid,l.l_date,l.no_of_days]
      );
  
      res.json(newLeave.rows[0]);
    } catch (err) {
      console.error(err.message);
    }
  });
  


app.delete("/delEmp", async (req, res) => {
  try {
    const id = req.query.ssn;
    console.log(id);
    const deleteTodo = await pool.query("DELETE FROM employee WHERE ssn = $1", [
      id
    ]);
    res.json("Employee was deleted!");
  } catch (err) {
    console.log(err.message);
  }
});




app.get("/ssnEmp", async (req, res) => {
    try {
      const e = req.query.ssn;
      const emp = await pool.query("SELECT * FROM employee WHERE ssn = $1", [e]);
      res.json(emp.rows);
    } catch (err) {
      console.error(err.message);
    }
});


app.get("/ssnSkill", async (req, res) => {
    try {
      const e = req.query.ssn;
      const emp = await pool.query("SELECT * FROM skill WHERE sid in (SELECT sid FROM employee_skill WHERE ssn= $1)" , [e]);
      res.json(emp.rows);
    } catch (err) {
      console.error(err.message);
    }
});
 

app.listen(5000, () => {
  console.log(`Server is starting on port 5000`);
});
