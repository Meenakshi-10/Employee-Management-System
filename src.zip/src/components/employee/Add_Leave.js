import React, { Component } from 'react';
import { Dropdown,Checkbox } from 'semantic-ui-react';
import { TextArea,Button,Form } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css'
import axios from 'axios' ;

const divStyle = {
	position: 'absolute',
	width: '70%',
	margin: '100px 0px'
};

class Add_Leave extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            ssn: 0,
            lid: 0,
            l_date: "", 
			no_of_days: 0
         }
    }

    myChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleDropdownChange = (event,data) => {
        this.setState({
            [data.name]: data.value
        });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        const { ssn,lid,l_date,no_of_days } = this.state;
        axios.post('http://localhost:5000/addleave', {
        ssn: ssn,
        lid: lid,
        l_date: l_date,
        no_of_days: no_of_days
        })
        .then((response) => {
        console.log(response);
        this.props.history.push('/');
        })
        .catch((error) => {
        console.log(error);
        });
        }
    
    render() {
        //const { value } = this.state;
        const LeaveOptions= [
            {
                key: 'Annual Leave',
                text: 'Annual',
                value: 1,
                name: 'lid',
            },

            {
                key: 'Loss of Pay Leave',
                text: 'Loss of Pay',
                value: 2,
                name: 'lid',
            },
			
			{
                key: 'Sick Leave',
                text: 'Sick',
                value: 3,
                name: 'lid',
            },
			
			{
                key: 'Maternity Leave',
                text: 'Maternity',
                value: 4,
                name: 'lid',
            },
			
			{
                key: 'Paternity Leave',
                text: 'Paternity',
                value: 5,
                name: 'lid',
            }
			

        ]

        return(
        <form style={divStyle} onSubmit = {this.handleSubmit}>
			<br/>
                <h1 align="center">EMPLOYEE DETAILS</h1>
				<br/>
				<br/>
                <div class= "ui center aligned grid">
            <div class="ui form eight wide column centered">

             
            <Form.Group widths='equal'>
                <Form.Input fluid label='Employee SSN' type="number" placeholder="Employee SSN" name="ssn" onChange= {this.myChangeHandler}/>
        
                <br/>

                <Form.Input label="Leave Type">
                    <Dropdown
                        placeholder='Leave Type'
                        fluid
                        selection
                        name="lid"
                        options={LeaveOptions}
                        onChange={this.handleDropdownChange}
                    />
                </Form.Input>
            </Form.Group> 

        
            
                
            <Form.Group widths='equal'>
                <Form.Input fluid label='Starting Date' type="date" placeholder="Starting Date" name="l_date" onChange= {this.myChangeHandler}/>
                <Form.Input fluid label='Number of Days' type="number" placeholder="Number of Days" name="no_of_days" onChange= {this.myChangeHandler}/>
            </Form.Group>    
                <Button type="Submit">
                    POST
                </Button>
                <br/>
				<br/>
                <Button type="Reset">
                    RESET
                </Button>
				<br/>
            </div>
            </div>
            </form>
         );
    }
  }

export default Add_Leave;