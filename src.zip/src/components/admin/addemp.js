import React, { Component } from 'react';
import { Dropdown,Checkbox } from 'semantic-ui-react';
import { TextArea,Button,Form } from 'semantic-ui-react';
import 'semantic-ui-css/semantic.min.css'
import axios from 'axios' ;

class Employee extends Component{
    constructor(props) {
        super(props);
        this.state = { 
            ssn: 0,
            b_date: "",
            Status:"", //temporary,permanent
			sex:"", //male,female
            s_name:"",
            l_name:"",
            address:"",
            grade:"" //3-10
         }
    }

    myChangeHandler = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }

    handleDropdownChange = (event,data) => {
        this.setState({
            [data.name]: data.value
        });
    }

    handleSubmit = (event) => {
        event.preventDefault();
        const { ssn,b_date,Status,sex,s_name,l_name,address,grade } = this.state;
        axios.post('http://localhost:5000/addemployee', {
        ssn: ssn,
        b_date: b_date,
        Status: Status,
        sex:sex,
        s_name:s_name,
        l_name:l_name,
        address:address,
        grade:grade
        })
        .then((response) => {
        console.log(response);
        this.props.history.push('/');
        })
        .catch((error) => {
        console.log(error);
        });
        }
    
    render() {
        const { value } = this.state;
        const statusOptions= [
            {
                key: 'Temporary',
                text: 'Temporary',
                value: 'temporary',
                name: 'Status',
            },

            {
                key: 'Permanent',
                text: 'Permanent',
                value: 'permanent',
                name: 'Status',
            }

        ]

        const sexOptions= [
            {
                key: 'Male',
                text: 'Male',
                value: 'male',
                name: 'sex',
            },

            {
                key: 'Female',
                text: 'Female',
                value: 'female',
                name: 'sex',
            }

        ]
		
		const divStyle = {
			position: 'absolute',
			width: '70%',
			margin: '60px -20px'
		};

        return(
        <form onSubmit = {this.handleSubmit} style={divStyle}>
			<br/> <br/> <br/> <br/> <br/>
                <h1 align="center">EMPLOYEE DETAILS</h1>
				<br/>
				<br/>
                <div class= "ui center aligned grid">
            <div class="ui form eight wide column centered">

             
            <Form.Group widths='equal'>
                
                
                <Form.Input fluid label='Employee SSN' type="number" placeholder="Employee SSN" name="ssn" onChange= {this.myChangeHandler}/>
                <Form.Input fluid label='First name' type="text" placeholder="First Name" name="s_name" onChange= {this.myChangeHandler}/>
                <Form.Input fluid label='Last name' type="text" placeholder="Last Name" name="l_name" onChange= {this.myChangeHandler}/>

            </Form.Group> 
        
                <br/>


            <Form.Group widths='equal'>
                <Form.Input label="Status">
                    <Dropdown
                        placeholder='Status'
                        fluid
                        selection
                        name="Status"
                        options={statusOptions}
                        onChange={this.handleDropdownChange}
                    />
                </Form.Input>

                <Form.Input label="Sex">
                    <Dropdown
                        placeholder='Sex'
                        fluid
                        selection
                        name="sex"
                        options={sexOptions}
                        onChange={this.handleDropdownChange}
                    />
                </Form.Input>
            </Form.Group> 

        
            
                
            <Form.Group widths='equal'>
                <Form.Input fluid label='Birth Date' type="date" placeholder="Birth Date" name="b_date" onChange= {this.myChangeHandler}/>
                <Form.Input fluid label='Grade' type="number" placeholder="Grade" name="grade" onChange= {this.myChangeHandler}/>
            </Form.Group>
            
            <Form.Group widths='equal'>
                <Form.Input fluid label='Address' type="textarea" placeholder="Address" name="address" onChange= {this.myChangeHandler}/>
            </Form.Group>
                
                <Button type="Submit">
                    POST
                </Button>
                <br/>
				<br/>
                <Button type="Reset">
                    RESET
                </Button>
				<br/>
            </div>
            </div>
            </form>
         );
    }
  }

export default Employee;