require('dotenv').config();

const Pool = require("pg").Pool;

const pool = new Pool({
    user: "postgres",
    password: "mina@1004",
    host: "localhost",
    port: 5432,
    database: "employeemanagement"
});

module.exports = pool;