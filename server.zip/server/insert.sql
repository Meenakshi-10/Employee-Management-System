INSERT INTO Salary_Range VALUES
(4, 30000, 35000),
(5, 40000, 55000),
(6, 60000, 70000),
(7, 72000, 80000),
(8, 85000, 95000);

INSERT INTO Employee VALUES
(1, '2000-11-03', 'permanent', 'female', 'Lalitha Sravanti', 'Dasu', 'HSR Layout',5),
(2, '2001-04-10', 'permanent', 'female', 'Meenakshi', 'Suresh', 'sector-5 HSR Layout, Bangalore',5),
(3, '2001-12-26', 'permanent', 'male', 'Lohith', 'Srinivas', 'Electronic City, Bangalore',4),
(4, '1983-03-20', 'permanent', 'male', 'Deep', 'Mehta', 'Bellandur, Bangalore',8),
(5, '2001-09-03', 'temporary', 'female', 'Satya', 'Rajan', 'Koramangala, Bangalore',4),
(6, '1989-11-05', 'permanent', 'female', 'Sunaina', 'Agrawal', 'Koramangala 5th block, Bangalore',7),
(7, '1991-03-10', 'permanent', 'male', 'Rahul', 'Mittal', 'Banashankari, Bangalore',6),
(8, '1997-07-12', 'permanent', 'male', 'Sanjay', 'Dutt', 'Whitefield, Bangalore',6),
(9, '2000-09-07', 'temporary', 'male', 'Vinod', 'Narayan', 'Bommanahalli, Bangalore',4),
(10, '1986-12-02', 'permanent', 'male', 'Neel', 'Roy', 'Bellandur, Bangalore',7);

INSERT INTO Dependents VALUES
('Sunitha Mehta', 4, 'female', '1985-07-21', 'wife'),
('Riya Mehta', 4, 'female', '2012-03-20', 'daughter'),
('Anika Sen', 4, 'female', '1965-04-05', 'mother'),
('Raj Agrawal', 6, 'male', '1984-03-02', 'husband'),
('Baldev Das', 6, 'male', '1959-09-12', 'father'),
('Chitra Suresh', 2, 'female', '1974-04-20', 'mother'),
('Abhimanyu Roy', 10, 'male', '1960-12-20', 'father'),
('Neelam Roy', 10, 'female', '1969-02-21', 'mother');

INSERT INTO Leave_type VALUES
(1, 'Annual Leave', 20),
(2, 'Loss of Pay Leave', 90),
(3, 'Sick Leave', 15),
(4, 'Maternity Leave', 180),
(5, 'Paternity Leave', 160);

INSERT INTO Building VALUES
(1, 'Verizon Corporation Limited',1000),
(2, 'Verizon Research Lab', 300);

INSERT INTO Department VALUES
(1,'Product Development',6),
(2,'Human Resources',4),
(3,'Technical Support',7),
(4,'Sales Support', 8),
(5,'Product Research', 10);

INSERT INTO Project VALUES
(1,'Fingerprint Voting System', 40000), 
(2,'Inventory Management', 50000),
(3,'Project Management Tool', 45000),
(4,'PDF Reader 2.1', 30000),
(5,'PDF Reader 2.1 Lite', 32000);

INSERT INTO Skill VALUES
(1, 'Big Data Analysis', 'Hadoop, Spark'), 
(2, 'Project Planning', 'Trello'),
(3, 'Quality Testing', 'Selenium'),
(4, 'Database Systems', 'Oracle'),
(5, 'Market Intelligence', 'Crunchbase'),
(6, 'Integrated Circuit Design', 'Cadence'),
(7, 'Object Oriented Design', 'C++'),
(8, 'Programming', 'C++/Java'),
(9, 'Written and Verbal Communication', 'None'),
(10, 'Mentoring', 'None');



INSERT INTO Department_Building VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(1, 2),
(3, 2),
(5, 2);

INSERT INTO Employee_Department VALUES
(1, 5),
(2, 1),
(3, 2),
(4, 2),
(5, 4),
(6, 1),
(7, 3),
(8, 4),
(9, 3),
(10, 5);

INSERT INTO Employee_Project VALUES
('2020-08-10', 6, 1, 1),
('2020-09-21', 6, 2, 1),
('2019-04-22', 6, 6, 1),
('2019-02-12', 7, 3, 1),
('2020-11-03', 7, 5, 1),
('2010-08-03', 7, 4, 2),
('2015-03-17', 10, 7, 2),
('2018-04-17', 5, 2, 2),
('2017-11-21', 7, 3, 3),
('2018-08-03', 8, 4, 3),
('2017-02-02', 6, 6, 3),
('2018-09-09', 8, 9, 3),
('2021-01-21', 8, 5, 4),
('2020-09-02', 6, 9, 4),
('2017-08-21', 7, 10, 4),
('2018-03-03', 8, 8, 5),
('2018-06-01', 7, 1, 5),
('2019-06-21', 8, 10, 5);

INSERT INTO Employee_Leave VALUES
(1, 3, '2021-03-01', 1),
(2, 3, '2021-03-02', 2),
(3, 3, '2020-03-01', 2),
(4, 1, '2017-09-02', 1),
(5, 3, '2020-03-02', 3),
(6, 4, '2017-02-21', 170),
(7, 5, '2021-09-12', 60),
(8, 5, '2018-02-12', 70),
(9, 2, '2019-11-02', 20),
(10, 3, '2020-12-02', 2),
(6, 3, '2019-11-21', 1),
(8, 3, '2017-12-23', 1),
(4, 2, '2020-03-03', 50),
(10, 1, '2019-09-09', 3),
(4, 3, '2018-09-12', 1),
(5, 2, '2020-09-02', 40),
(8, 1, '2020-02-01', 2);

INSERT INTO Employee_Skill VALUES
(1, 7),
(1, 8),
(2, 4),
(2, 8),
(3, 2),
(3, 9),
(4, 9),
(4, 10),
(5, 9),
(5, 3),
(5, 5),
(6, 10),
(6, 1),
(6, 6),
(7, 8),
(7, 9),
(8, 5),
(8, 9),
(8, 10),
(9, 8),
(10, 10),
(10, 6),
(10, 8);

INSERT INTO Project_Department VALUES
(1, 5),
(1, 1),
(1, 2),
(1, 4),
(2, 4),
(2, 1),
(3, 2),
(3, 1),
(3, 3),
(4, 4),
(4, 3),
(4, 5),
(5, 4),
(5, 5);

