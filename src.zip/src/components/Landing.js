import React from "react";
import { Link } from "react-router-dom";
import pic from "./images/pic.jpg"

const Style = {
	width:'600px',
	height:'400px',
	margin:'50px 0px'
};

const divStyle = {
	width:'500px',
	height:'600px',
	border:'solid 1px white',
	color:'grey',
	margin:'50px 0px',
	align: 'left',
	textAlign: 'center'
};

const btnStyle = {
	display: 'inline-block',
	margin: '0px 40px',
	
	border: '2px solid black'
};

const btnStyle2 = {
	display: 'inline-block',
	margin: '0px 15px',
	border: '2px solid black'
};

const Landing = () => {
  return (
	<div>
	<img src={pic} alt="img" align="right" style={Style} />
	<div style={divStyle}>
	<br/> <br/>
	<br/> <br/>
	<br/> <br/>
	<br/>
      <h1>Employee</h1>
	  <h1>Management</h1>
	  <h1>System</h1>
      <br/> <br/> 
	  <Link to="/login" className="btn" style={btnStyle}>
       Login
      </Link>
      <Link to="/register" className="btn btn-default" style={btnStyle2}>
        Register
      </Link>
	  
	</div>
    </div>
  );
};

export default Landing;
